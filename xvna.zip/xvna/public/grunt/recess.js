module.exports = {
    style: {
        files: {
            'angular/css/app.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style2: {
        files: {
            'angular/css/app.style2.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style2.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style3: {
        files: {
            'angular/css/app.style3.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style3.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style4: {
        files: {
            'angular/css/app.style4.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style4.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style5: {
        files: {
            'angular/css/app.style5.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style5.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style6: {
        files: {
            'angular/css/app.style6.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style6.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style7: {
        files: {
            'angular/css/app.style7.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style7.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style8: {
        files: {
            'angular/css/app.style8.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style8.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    },
    style9: {
        files: {
            'angular/css/app.style9.min.css': [

                'bower_components/bootstrap/dist/css/bootstrap.css',
                'bower_components/bootstrap/dist/css/bootstrap-theme.css',
                'bower_components/animate.css/animate.css',
                'app/css/app.style9.css',
                'app/css/material-icons.css',
                'app/css/videogular.css'
            ]
        },
        options: {
            compress: true
        }
    }
}

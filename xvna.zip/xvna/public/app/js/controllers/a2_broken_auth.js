app.controller('a2_brokenauth_ctrl', ['$scope', function($scope) {
  

}]);

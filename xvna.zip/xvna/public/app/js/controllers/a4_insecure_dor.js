app.controller('a4_insecuredor_ctrl', ['$scope', function($scope) {
  

}]);

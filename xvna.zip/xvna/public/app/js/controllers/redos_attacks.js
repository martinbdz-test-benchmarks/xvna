app.controller('redos_attacks_ctrl', ['$scope', function($scope) {
  

}]);
